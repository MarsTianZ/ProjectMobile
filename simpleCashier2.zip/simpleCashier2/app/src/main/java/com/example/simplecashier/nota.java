package com.example.simplecashier;

public interface nota {
}
